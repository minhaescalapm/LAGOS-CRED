import React, { useState } from "react";
import { ClientWithLoanDetails, FinancialStats, Loan, Payment } from "../types";
import { getFinancialCycle, getTodayStr, addDays, formatFriendlyDate } from "../utils/dateUtils";
import { 
  TrendingUp, 
  ArrowDownCircle, 
  Award, 
  Coins, 
  Gauge, 
  Percent, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle,
  ArrowUpRight,
  Sparkles,
  DollarSign,
  HelpCircle,
  PiggyBank,
  Search,
  Users,
  CheckCircle2,
  Clock
} from "lucide-react";

interface FinancialControlProps {
  clientsWithLoans: ClientWithLoanDetails[];
  stats: FinancialStats;
  allLoans: Loan[];
  allPayments: Payment[];
}

export const FinancialControl: React.FC<FinancialControlProps> = ({
  clientsWithLoans,
  stats,
  allLoans,
  allPayments
}) => {
  // Simulator configuration states
  const [simulationMoMGrace, setSimulationMoMGrace] = useState<number>(20); // 20% requested default
  const [customInterestRate, setCustomInterestRate] = useState<number>(42); // 42% standard interest rate defaulted
  const [reportTab, setReportTab] = useState<"saldos_receber" | "semanal" | "mensal" | "reinvestimentos">("saldos_receber");
  const [remainingSearchTerm, setRemainingSearchTerm] = useState<string>("");
  const [newAporteAmount, setNewAporteAmount] = useState<number>(1000);
  const [newAporteRate, setNewAporteRate] = useState<number>(30);

  // 1. Calculate general financial aggregates from database
  const totalLent = allLoans.reduce((sum, l) => sum + l.amountInvested, 0);
  const totalReceived = allPayments.reduce((sum, p) => sum + p.amount, 0);

  // Calculation of Remaining Balance per Client and Grand Sum
  const clientsRemainingBalances = clientsWithLoans
    .filter(c => c.activeLoan !== null && !c.client.archived)
    .map(c => {
      const loan = c.activeLoan!;
      const paidCount = c.paidCount;
      const totalDays = loan.totalDays;
      const remainingCount = Math.max(0, totalDays - paidCount);
      const remainingAmount = remainingCount * loan.dailyRate;
      const totalContract = loan.totalAmount || (loan.dailyRate * totalDays);
      return {
        client: c.client,
        loan,
        paidCount,
        totalDays,
        remainingCount,
        remainingAmount,
        totalContract,
        isDelayed: c.isDelayed,
        daysBehind: c.daysBehind
      };
    })
    .sort((a, b) => b.remainingAmount - a.remainingAmount);

  const activeRemainingClients = clientsRemainingBalances.filter(c => c.remainingCount > 0);
  const totalRemainingSum = activeRemainingClients.reduce((sum, c) => sum + c.remainingAmount, 0);
  const totalRemainingInstallments = activeRemainingClients.reduce((sum, c) => sum + c.remainingCount, 0);

  const filteredRemainingClients = activeRemainingClients.filter(c => 
    c.client.name.toLowerCase().includes(remainingSearchTerm.toLowerCase()) ||
    c.client.phone.includes(remainingSearchTerm)
  );

  // Find payments received in the last 7 days (Weekly report)
  const todayStr = getTodayStr();
  const sevenDaysAgo = addDays(todayStr, -6);
  const weeklyPayments = allPayments.filter(p => p.paymentDate >= sevenDaysAgo && p.paymentDate <= todayStr);
  
  // Find payments received in current month cycle (Monthly report)
  const currentMonthCycleData = getFinancialCycle(todayStr);
  const monthlyPayments = allPayments.filter(p => p.paymentDate >= currentMonthCycleData.start && p.paymentDate <= currentMonthCycleData.end);

  // Helper to resolve client name from loanId
  const getClientNameForPayment = (pay: Payment) => {
    const loan = allLoans.find(l => l.id === pay.loanId);
    if (!loan) return "Contrato Antigo";
    const clientDetail = clientsWithLoans.find(c => c.client.id === loan.clientId);
    return clientDetail ? clientDetail.client.name : "Cliente Desconhecido";
  };

  // Helper to calculate exact profit (juros) and principal (amortização) for a given payment
  const getPaymentComponents = (pay: Payment) => {
    const loan = allLoans.find(l => l.id === pay.loanId);
    if (!loan || loan.amountInvested <= 0) return { profit: 0, principal: pay.amount };
    const totalAmt = loan.totalAmount || (loan.dailyRate * loan.totalDays);
    if (totalAmt <= 0) return { profit: 0, principal: pay.amount };
    const profitRatio = (totalAmt - loan.amountInvested) / totalAmt;
    const profit = pay.amount * profitRatio;
    const principal = pay.amount - profit;
    return { profit, principal };
  };
  
  // Realized Profit = received payments minus the proportion of principal returned (or active interest rate return)
  // For simplicity and finance elegance, let's calculate Net Interest Profit Collected:
  // Since we know the average interest rate is ~30%, the principal component is ~77%, and interest is ~23%.
  // Or we can calculate it exactly: we can sum the profit portions of loans.
  // Let's compute exact cumulative profit under active terms:
  const totalRevenueExpected = allLoans.reduce((sum, l) => sum + (l.totalAmount || (l.dailyRate * l.totalDays)), 0);
  const projectedInterestProfit = totalRevenueExpected - totalLent;
  
  // Received profit can be estimated by: totalReceived - (principal portion of that received amount)
  // Or simply: totalReceived - totalLent (if we consider direct flow), but since we operate like an active fund:
  // Let's showcase standard cashflow: 
  // Entradas = totalReceived
  // Saídas = totalLent
  // Lucro Atual (Saldo em Caixa) = totalReceived - totalLent (if negative, it's normal as capital is out on the streets. Let's call it "Saldo de Caixa Ativo").
  // Lucro Realizado Real (Juros Cobrados):
  const realizedProfitExact = allPayments.reduce((pSum, pay) => {
    // Find corresponding loan
    const loan = allLoans.find(l => l.id === pay.loanId);
    if (!loan || loan.amountInvested === 0) return pSum;
    const totalAmt = loan.totalAmount || (loan.dailyRate * loan.totalDays);
    if (totalAmt <= 0) return pSum;
    const profitRatio = (totalAmt - loan.amountInvested) / totalAmt;
    return pSum + (pay.amount * profitRatio);
  }, 0);

  // Profit realized in current month's cycle (Starts on day 02)
  const currentMonthCycle = getFinancialCycle(getTodayStr());
  const realizedProfitThisMonth = allPayments
    .filter(p => p.paymentDate >= currentMonthCycle.start && p.paymentDate <= currentMonthCycle.end)
    .reduce((pSum, pay) => {
      const loan = allLoans.find(l => l.id === pay.loanId);
      if (!loan || loan.amountInvested === 0) return pSum;
      const totalAmt = loan.totalAmount || (loan.dailyRate * loan.totalDays);
      if (totalAmt <= 0) return pSum;
      const profitRatio = (totalAmt - loan.amountInvested) / totalAmt;
      return pSum + (pay.amount * profitRatio);
    }, 0);

  // 2. Metrics for Pagantes (Up-to-Date) vs Inadimplentes (Delayed)
  const activeClients = clientsWithLoans.filter(c => c.activeLoan !== null);
  const payingClients = activeClients.filter(c => !c.isDelayed);
  const delinquentClients = activeClients.filter(c => c.isDelayed);

  const payingCount = payingClients.length;
  const delinquentCount = delinquentClients.length;
  const totalActiveCount = activeClients.length;

  // Delinquency rate calculations (NPL %)
  const defaultRateByClient = totalActiveCount > 0 ? (delinquentCount / totalActiveCount) * 100 : 0;
  
  // --- BLINDAGEM DE LUCROS & COMPENSAÇÃO DE INADIMPLÊNCIA MATEMÁTICA ENGENHADA ---
  const activeDefaultRate = defaultRateByClient > 0 ? defaultRateByClient : 15;
  const breakEvenInterestRate = (activeDefaultRate / (100 - Math.min(99, activeDefaultRate))) * 100;
  const maxDefaultTolerance = (1 - (1 / (1 + (customInterestRate / 100)))) * 100;
  const netInvestmentYieldProfit = ((1 - (activeDefaultRate / 100)) * (1 + (customInterestRate / 100)) - 1) * 100;
  
  // Delinquency by Value (overdue amount)
  const totalOverdueAmount = delinquentClients.reduce((sum, c) => {
    if (!c.activeLoan) return sum;
    // Overdue installments = expected payments to date - received payments to date
    // Actually, we already have c.daysBehind * c.activeLoan.dailyRate
    return sum + (c.daysBehind * c.activeLoan.dailyRate);
  }, 0);

  // Active Monthly Billing Runway (Faturamento Mensal Ativo)
  // Calculated as sum of (dailyRate * 30) of all active payers
  const activeMonthlyBillingPayers = payingClients.reduce((sum, c) => {
    if (!c.activeLoan) return sum;
    return sum + (c.activeLoan.dailyRate * 30);
  }, 0);

  const activeMonthlyBillingDelinquent = delinquentClients.reduce((sum, c) => {
    if (!c.activeLoan) return sum;
    return sum + (c.activeLoan.dailyRate * 30);
  }, 0);

  const totalActiveMonthlyBilling = activeMonthlyBillingPayers + activeMonthlyBillingDelinquent;

  // 3. 20% MoM SYSTEM GROWTH SIMULATOR
  // The goal: Grow billing by X% (MoM - standard default is 20%)
  const growthTargetPct = simulationMoMGrace / 100;
  const currentBillingForGrowth = totalActiveMonthlyBilling > 0 ? totalActiveMonthlyBilling : 15000; // fallback default to make it interactive even when wiped
  const targetBillingChangeNeeded = currentBillingForGrowth * growthTargetPct;
  const targetMonthlyBilling = currentBillingForGrowth + targetBillingChangeNeeded;

  // How much do we need to lend to capture that billing change next month?
  // Let's calculate: 
  // New Monthly Billing needed = targetBillingChangeNeeded.
  // Standard monthly return of a contract is 1.30x the principal (for 30% interest).
  // So Billing = Principal * (1 + interestRate/100).
  // Thus, Capital needed to lend = New Monthly Billing needed / (1 + interestRate/100).
  //BUT we must take delinquency/default rate into account!
  // If default rate is D%, only (1 - D) of the new loans will pay on time.
  // So to guarantee a net increase of targetBillingChangeNeeded, we must inflate the target by 1 / (1 - D).
  const defaultRatioFactor = defaultRateByClient > 0 ? (defaultRateByClient / 100) : 0.15; // default to 15% safety buffer if no default exists currently
  // Cap safety buffer to avoid division by zero
  const safeDefaultRatio = Math.min(0.5, defaultRatioFactor); 
  const riskAdjustedBillingNeeded = targetBillingChangeNeeded / (1 - safeDefaultRatio);
  
  // Total capital needed to lend:
  const interestFactor = 1 + (customInterestRate / 100);
  const requiredCapitalToLend = riskAdjustedBillingNeeded / interestFactor;
  
  // Number of average new contracts needed (assume average loan of $1,500)
  const averageLoanSize = 1500;
  const contractsCountNeeded = Math.ceil(requiredCapitalToLend / averageLoanSize);

  // Formatter helper
  const formatBRL = (val: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL"
    }).format(val);
  };

  return (
    <div className="space-y-6 select-none animate-fade-in text-zinc-100">
      
      {/* SECTION 1: FINANCIAL FLOW CARD ROW */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        
        {/* CARD 1: ENTRADAS */}
        <div className="bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-emerald-500/30 transition-all">
          <div className="absolute top-0 right-0 p-3 opacity-5">
            <ArrowDownCircle className="w-16 h-16 text-emerald-400" />
          </div>
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
              <ArrowDownCircle className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider font-mono">Entradas (Repasses Coletados)</span>
          </div>
          <div>
            <h3 className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono tracking-tight text-emerald-450">
              {formatBRL(totalReceived)}
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1">Soma total de todas as parcelas pagas no caixa</p>
          </div>
        </div>

        {/* CARD 2: SAÍDAS */}
        <div className="bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-red-550/30 transition-all">
          <div className="absolute top-0 right-0 p-3 opacity-5">
            <TrendingUp className="w-16 h-16 text-red-400" />
          </div>
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 bg-red-500/10 text-red-400 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider font-mono">Saídas (Capital Emprestado)</span>
          </div>
          <div>
            <h3 className="text-2xl sm:text-3xl font-black text-zinc-100 font-mono tracking-tight">
              {formatBRL(totalLent)}
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1">Acúmulo histórico de capital disponibilizado</p>
          </div>
        </div>

        {/* CARD 3: RESTANTE A RECEBER (TODOS CLIENTES) */}
        <div className="bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-sky-500/30 transition-all">
          <div className="absolute top-0 right-0 p-3 opacity-5">
            <Coins className="w-16 h-16 text-sky-400" />
          </div>
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 bg-sky-500/10 text-sky-400 rounded-lg">
              <Coins className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider font-mono">Restante a Receber (Todos Clientes)</span>
          </div>
          <div>
            <h3 className="text-2xl sm:text-3xl font-black text-sky-400 font-mono tracking-tight">
              {formatBRL(totalRemainingSum)}
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1">Soma de todos os saldos restantes devedores ({totalRemainingInstallments} parcelas)</p>
          </div>
        </div>

        {/* CARD 4: LUCRO REALIZADO DE JUROS */}
        <div className="bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-amber-400/30 transition-all">
          <div className="absolute top-0 right-0 p-3 opacity-5">
            <Award className="w-16 h-16 text-amber-400" />
          </div>
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 bg-amber-400/10 text-amber-400 rounded-lg">
              <Award className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider font-mono">Lucro de Juros Realizado</span>
          </div>
          <div>
            <h3 className="text-2xl sm:text-3xl font-black text-amber-400 font-mono tracking-tight">
              {formatBRL(realizedProfitExact)}
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1">Total de juros líquido recuperado dos pagamentos</p>
          </div>
        </div>

        {/* CARD 5: LUCRO MENSAL */}
        <div className="bg-zinc-950/40 border border-zinc-850 p-5 rounded-2xl flex flex-col justify-between relative overflow-hidden group hover:border-violet-500/30 transition-all">
          <div className="absolute top-0 right-0 p-3 opacity-5">
            <PiggyBank className="w-16 h-16 text-violet-400" />
          </div>
          <div className="flex items-center gap-2 mb-3">
            <div className="p-2 bg-violet-500/10 text-violet-400 rounded-lg">
              <PiggyBank className="w-4 h-4" />
            </div>
            <span className="text-[10px] uppercase font-bold text-zinc-400 tracking-wider font-mono">Lucro Mensal (Mês Atual)</span>
          </div>
          <div>
            <h3 className="text-2xl sm:text-3xl font-black text-violet-400 font-mono tracking-tight">
              {formatBRL(realizedProfitThisMonth)}
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1">Juros líquidos recuperados no ciclo atual (Dia 02)</p>
          </div>
        </div>

      </div>

      {/* SECTION: DETALHAMENTO DE RELATÓRIOS E COMPOSIÇÃO DE JUROS COM ABAS */}
      <div className="bg-zinc-950/40 border border-zinc-850 rounded-2xl p-5 space-y-5 select-none animate-fade-in">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-zinc-900">
          <div className="flex items-center gap-2">
            <Coins className="w-5 h-5 text-amber-400" />
            <div>
              <h4 className="font-extrabold text-sm uppercase tracking-wider text-zinc-100">Detalhamento Analítico de Caixa e Lucros</h4>
              <p className="text-[10px] text-zinc-500 mt-0.5">Visão transparente de juros ganhos, amortizações e do fluxo de aportes continuados</p>
            </div>
          </div>
          
          {/* Sub-tabs selector with premium design matching layout guidelines */}
          <div className="flex bg-zinc-900/80 p-1 rounded-xl border border-zinc-800 self-start md:self-auto gap-1 flex-wrap">
            <button
              onClick={() => setReportTab("saldos_receber")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                reportTab === "saldos_receber"
                  ? "bg-amber-400 text-zinc-950 shadow-md shadow-amber-400/10"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              <Coins className="w-3.5 h-3.5" />
              Saldos a Receber ({activeRemainingClients.length})
            </button>
            <button
              onClick={() => setReportTab("semanal")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                reportTab === "semanal"
                  ? "bg-amber-400 text-zinc-950 shadow-md shadow-amber-400/10"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              Lucros Semanais
            </button>
            <button
              onClick={() => setReportTab("mensal")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                reportTab === "mensal"
                  ? "bg-amber-400 text-zinc-950 shadow-md shadow-amber-400/10"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              Lucros Mensais
            </button>
            <button
              onClick={() => setReportTab("reinvestimentos")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                reportTab === "reinvestimentos"
                  ? "bg-amber-400 text-zinc-950 shadow-md shadow-amber-400/10"
                  : "text-zinc-400 hover:text-zinc-200"
              }`}
            >
              Aportes & Reinvestimento
            </button>
          </div>
        </div>

        {/* SUB-TAB: SALDOS A RECEBER (TODOS OS CLIENTES) */}
        {reportTab === "saldos_receber" && (
          <div className="space-y-4 animate-fade-in">
            {/* Summary Metrics Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-sky-500/20">
                <span className="text-[9px] text-sky-400 uppercase font-bold tracking-wider block">Total a Receber Ainda</span>
                <span className="text-xl font-black text-sky-400 font-mono block mt-1">
                  {formatBRL(totalRemainingSum)}
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Soma exata de todos os saldos restantes ativos</span>
              </div>
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-zinc-400 uppercase font-bold tracking-wider block">Diárias Restantes no Total</span>
                <span className="text-xl font-black text-zinc-200 font-mono block mt-1">
                  {totalRemainingInstallments} <span className="text-xs text-zinc-500 font-normal">parcelas</span>
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Volume de cobranças diárias a serem recebidas</span>
              </div>
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-zinc-400 uppercase font-bold tracking-wider block">Clientes com Saldo Devedor</span>
                <span className="text-xl font-black text-zinc-200 font-mono block mt-1">
                  {activeRemainingClients.length} <span className="text-xs text-zinc-500 font-normal">clientes ativos</span>
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Contratos em andamento com parcelas a pagar</span>
              </div>
            </div>

            {/* Filter Search Input */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-zinc-900/30 p-2.5 rounded-xl border border-zinc-850">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filtrar por nome ou telefone do cliente..."
                  value={remainingSearchTerm}
                  onChange={(e) => setRemainingSearchTerm(e.target.value)}
                  className="w-full bg-zinc-950/70 border border-zinc-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                />
              </div>
              <span className="text-[10px] text-zinc-500 font-mono self-center px-1">
                Mostrando {filteredRemainingClients.length} de {activeRemainingClients.length} clientes
              </span>
            </div>

            {/* Remaining Balances Table */}
            <div className="border border-zinc-900 rounded-xl overflow-hidden bg-zinc-950/20">
              {filteredRemainingClients.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 text-xs flex flex-col items-center gap-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500/40" />
                  <span>
                    {remainingSearchTerm 
                      ? "Nenhum cliente encontrado com esse termo." 
                      : "Nenhum saldo pendente a receber! Todos os contratos estão quitados."}
                  </span>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-zinc-900/40 text-zinc-400 border-b border-zinc-850 text-[10px] font-bold uppercase tracking-wider">
                        <th className="py-2.5 px-4">Cliente</th>
                        <th className="py-2.5 px-3 text-right">Investido</th>
                        <th className="py-2.5 px-3 text-right">Diária</th>
                        <th className="py-2.5 px-3 text-right">Total Contrato</th>
                        <th className="py-2.5 px-3 text-center">Progresso</th>
                        <th className="py-2.5 px-3 text-center">Restam</th>
                        <th className="py-2.5 px-4 text-right text-sky-400 font-black">Restante a Pagar</th>
                        <th className="py-2.5 px-3 text-center">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-900/60 font-mono">
                      {filteredRemainingClients.map((item) => (
                        <tr key={item.loan.id} className="hover:bg-zinc-900/30 transition-colors">
                          <td className="py-2.5 px-4 font-sans">
                            <div className="font-bold text-zinc-200 text-xs">{item.client.name}</div>
                            <div className="text-[10px] text-zinc-500 font-mono">
                              {item.client.phone.replace(/(\d{2})(\d{5})(\d{4})/, "($1) $2-$3")}
                            </div>
                          </td>
                          <td className="py-2.5 px-3 text-right text-zinc-400 font-bold">
                            {formatBRL(item.loan.amountInvested)}
                          </td>
                          <td className="py-2.5 px-3 text-right text-yellow-500 font-bold">
                            {formatBRL(item.loan.dailyRate)}
                          </td>
                          <td className="py-2.5 px-3 text-right text-zinc-300 font-bold">
                            {formatBRL(item.totalContract)}
                          </td>
                          <td className="py-2.5 px-3 text-center font-bold text-zinc-300">
                            {item.paidCount} / {item.totalDays}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className="px-1.5 py-0.5 rounded bg-zinc-900 text-zinc-300 font-bold text-[10px]">
                              {item.remainingCount}x
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-right">
                            <span className="font-bold text-sky-400 text-xs">
                              {formatBRL(item.remainingAmount)}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-center font-sans">
                            {item.isDelayed ? (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded text-[9px] font-bold">
                                <AlertTriangle className="w-2.5 h-2.5" />
                                Atrasado (-{item.daysBehind})
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-zinc-800 text-zinc-400 rounded text-[9px] font-bold">
                                <Clock className="w-2.5 h-2.5" />
                                Em dia
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-zinc-900/60 text-white font-bold border-t-2 border-zinc-800 font-mono text-xs">
                        <td className="py-3 px-4 uppercase font-sans text-[11px] text-zinc-300">
                          Soma Total Geral ({filteredRemainingClients.length} clientes)
                        </td>
                        <td className="py-3 px-3 text-right text-zinc-300">
                          {formatBRL(filteredRemainingClients.reduce((sum, c) => sum + c.loan.amountInvested, 0))}
                        </td>
                        <td className="py-3 px-3 text-right text-yellow-500">
                          -
                        </td>
                        <td className="py-3 px-3 text-right text-zinc-200">
                          {formatBRL(filteredRemainingClients.reduce((sum, c) => sum + c.totalContract, 0))}
                        </td>
                        <td className="py-3 px-3 text-center text-zinc-300">
                          {filteredRemainingClients.reduce((sum, c) => sum + c.paidCount, 0)} pagas
                        </td>
                        <td className="py-3 px-3 text-center text-amber-400">
                          {filteredRemainingClients.reduce((sum, c) => sum + c.remainingCount, 0)}x rest.
                        </td>
                        <td className="py-3 px-4 text-right text-sky-400 font-black text-sm">
                          {formatBRL(filteredRemainingClients.reduce((sum, c) => sum + c.remainingAmount, 0))}
                        </td>
                        <td className="py-3 px-3 text-center text-[10px] text-zinc-400 font-sans">
                          Pendente
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUB-TAB: WEEKLY REPORT */}
        {reportTab === "semanal" && (
          <div className="space-y-4 animate-fade-in">
            {/* Summary Metrics Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-zinc-500 uppercase font-bold tracking-wider block">Entradas da Semana</span>
                <span className="text-lg font-black text-white font-mono block mt-1">
                  {formatBRL(weeklyPayments.reduce((sum, p) => sum + p.amount, 0))}
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Soma arrecadada nos últimos 7 dias</span>
              </div>
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-emerald-400 uppercase font-bold tracking-wider block">Lucro Realizado (Juros)</span>
                <span className="text-lg font-black text-emerald-400 font-mono block mt-1">
                  {formatBRL(
                    weeklyPayments.reduce((sum, p) => sum + getPaymentComponents(p).profit, 0)
                  )}
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Fração líquida correspondente aos juros</span>
              </div>
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-zinc-400 uppercase font-bold tracking-wider block">Capital Amortizado</span>
                <span className="text-lg font-black text-zinc-300 font-mono block mt-1">
                  {formatBRL(
                    weeklyPayments.reduce((sum, p) => sum + getPaymentComponents(p).principal, 0)
                  )}
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Retorno do principal emprestado para reinvestimento</span>
              </div>
            </div>

            {/* Payments Table */}
            <div className="border border-zinc-900 rounded-xl overflow-hidden bg-zinc-950/20">
              <div className="p-3 bg-zinc-900/40 border-b border-zinc-900 flex justify-between items-center">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider font-mono">
                  Lançamentos Semanais (Últimos 7 dias)
                </span>
                <span className="text-[10px] text-zinc-500 font-mono font-bold">
                  {weeklyPayments.length} depósitos registrados
                </span>
              </div>
              
              {weeklyPayments.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 text-xs">
                  Nenhum repasse coletado nesta semana.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-zinc-900/20 text-zinc-550 border-b border-zinc-900 text-[10px] font-bold uppercase tracking-wider">
                        <th className="py-2 px-4">Data</th>
                        <th className="py-2 px-4">Cliente</th>
                        <th className="py-2 px-4 text-right">Repasse Total</th>
                        <th className="py-2 px-4 text-right text-emerald-400/90">Lucro de Juros</th>
                        <th className="py-2 px-4 text-right text-zinc-400">Amortização</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-900/60">
                      {weeklyPayments.map(p => {
                        const comp = getPaymentComponents(p);
                        return (
                          <tr key={p.id} className="hover:bg-zinc-900/20 font-mono">
                            <td className="py-2.5 px-4 text-zinc-400">{formatFriendlyDate(p.paymentDate)}</td>
                            <td className="py-2.5 px-4 font-sans font-bold text-zinc-200">{getClientNameForPayment(p)}</td>
                            <td className="py-2.5 px-4 text-right font-bold text-zinc-100">{formatBRL(p.amount)}</td>
                            <td className="py-2.5 px-4 text-right text-emerald-400 font-bold">{formatBRL(comp.profit)}</td>
                            <td className="py-2.5 px-4 text-right text-zinc-400">{formatBRL(comp.principal)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUB-TAB: MONTHLY REPORT */}
        {reportTab === "mensal" && (
          <div className="space-y-4 animate-fade-in">
            {/* Cycle info bar */}
            <div className="p-3 bg-gradient-to-r from-amber-950/10 to-zinc-900/40 border border-amber-500/10 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="text-[11px] text-zinc-300">
                📅 <strong>Ciclo Financeiro Corrente:</strong> Do dia <span className="text-amber-400 font-bold">02 do mês atual</span> até o dia <span className="text-amber-400 font-bold">01 do mês subsequente</span>.
              </div>
              <span className="text-[10px] bg-amber-400/10 text-amber-400 font-black px-2 py-0.5 rounded-md font-mono uppercase tracking-wider">
                Rollover Dia 02
              </span>
            </div>

            {/* Summary Metrics Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-zinc-500 uppercase font-bold tracking-wider block">Entradas do Ciclo</span>
                <span className="text-lg font-black text-white font-mono block mt-1">
                  {formatBRL(monthlyPayments.reduce((sum, p) => sum + p.amount, 0))}
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Arrecadação acumulada no período</span>
              </div>
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-violet-400 uppercase font-bold tracking-wider block">Lucro Realizado (Juros)</span>
                <span className="text-lg font-black text-violet-400 font-mono block mt-1">
                  {formatBRL(
                    monthlyPayments.reduce((sum, p) => sum + getPaymentComponents(p).profit, 0)
                  )}
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Juros reais coletados no ciclo corrente</span>
              </div>
              <div className="bg-zinc-900/40 p-3.5 rounded-xl border border-zinc-900">
                <span className="text-[9px] text-zinc-400 uppercase font-bold tracking-wider block">Capital Amortizado</span>
                <span className="text-lg font-black text-zinc-300 font-mono block mt-1">
                  {formatBRL(
                    monthlyPayments.reduce((sum, p) => sum + getPaymentComponents(p).principal, 0)
                  )}
                </span>
                <span className="text-[9px] text-zinc-500 block mt-0.5">Capital que voltou ao caixa pronto para novos aportes</span>
              </div>
            </div>

            {/* Payments Table */}
            <div className="border border-zinc-900 rounded-xl overflow-hidden bg-zinc-950/20">
              <div className="p-3 bg-zinc-900/40 border-b border-zinc-900 flex justify-between items-center">
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider font-mono">
                  Lançamentos Mensais ({currentMonthCycleData.label})
                </span>
                <span className="text-[10px] text-zinc-500 font-mono font-bold">
                  {monthlyPayments.length} depósitos registrados
                </span>
              </div>
              
              {monthlyPayments.length === 0 ? (
                <div className="p-8 text-center text-zinc-500 text-xs">
                  Nenhum repasse coletado neste ciclo mensal ainda.
                </div>
              ) : (
                <div className="overflow-y-auto max-h-[300px] scrollbar-thin">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-zinc-900/20 text-zinc-550 border-b border-zinc-900 text-[10px] font-bold uppercase tracking-wider sticky top-0">
                        <th className="py-2 px-4 bg-zinc-950">Data</th>
                        <th className="py-2 px-4 bg-zinc-950">Cliente</th>
                        <th className="py-2 px-4 text-right bg-zinc-950">Repasse Total</th>
                        <th className="py-2 px-4 text-right text-violet-400 bg-zinc-950">Lucro de Juros</th>
                        <th className="py-2 px-4 text-right text-zinc-400 bg-zinc-950">Amortização</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-900/60">
                      {monthlyPayments.map(p => {
                        const comp = getPaymentComponents(p);
                        return (
                          <tr key={p.id} className="hover:bg-zinc-900/20 font-mono">
                            <td className="py-2 px-4 text-zinc-400">{formatFriendlyDate(p.paymentDate)}</td>
                            <td className="py-2 px-4 font-sans font-bold text-zinc-200">{getClientNameForPayment(p)}</td>
                            <td className="py-2 px-4 text-right font-bold text-zinc-100">{formatBRL(p.amount)}</td>
                            <td className="py-2 px-4 text-right text-violet-400 font-bold">{formatBRL(comp.profit)}</td>
                            <td className="py-2 px-4 text-right text-zinc-400">{formatBRL(comp.principal)}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Historical monthly cycles from stats */}
            {stats.pastReceived && Object.keys(stats.pastReceived).length > 0 && (
              <div className="space-y-2">
                <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest font-mono block">
                  Histórico de Fechamento por Ciclo Financeiro (Virando Todo Dia 02)
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {Object.entries(stats.pastReceived).map(([label, amount]) => (
                    <div key={label} className="bg-zinc-900/20 p-3 rounded-xl border border-zinc-900">
                      <span className="text-[9px] text-zinc-500 font-bold block">{label}</span>
                      <strong className="text-xs font-mono text-zinc-300 block mt-1">{formatBRL(amount as number)}</strong>
                      <span className="text-[8px] text-zinc-600 block mt-0.5">Total coletado</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* SUB-TAB: REINVESTMENTS & APORTES */}
        {reportTab === "reinvestimentos" && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 animate-fade-in">
            {/* Left explanation text: 5 cols */}
            <div className="lg:col-span-5 space-y-4">
              <div className="bg-gradient-to-b from-zinc-900 to-zinc-950 p-4 border border-zinc-850 rounded-2xl space-y-3">
                <h5 className="font-extrabold text-xs text-amber-400 uppercase tracking-wider font-mono">
                  🔄 Estratégia de Aportes Contínuos
                </h5>
                <p className="text-xs text-zinc-400 leading-relaxed text-justify">
                  Sempre que um cliente realiza os pagamentos das parcelas diárias, você recebe de volta duas coisas: o <strong>lucro de juros</strong> e o <strong>capital amortizado</strong> (investimento inicial).
                </p>
                <p className="text-xs text-zinc-400 leading-relaxed text-justify">
                  Para que o seu capital renda de forma exponencial e a engrenagem nunca pare, o modelo ideal é <strong>sacar apenas o lucro de juros e manter o investimento inicial trabalhando</strong> ("nunca para de investir"). 
                </p>
                <div className="p-3.5 bg-yellow-500/5 border border-yellow-500/25 rounded-xl text-[10px] text-amber-400 leading-normal font-mono">
                  ✨ <strong>Cálculo de Aporte Ativo:</strong> Ao renovar ou fazer novos aportes, o capital principal é reaplicado instantaneamente na rua, perpetuando o rendimento diário de microcrédito sem queimar caixa pessoal.
                </div>
              </div>
            </div>

            {/* Right compounding simulator: 7 cols */}
            <div className="lg:col-span-7 bg-zinc-900/30 border border-zinc-850 rounded-2xl p-4 space-y-4">
              <h5 className="font-extrabold text-xs uppercase tracking-wider text-zinc-300">
                🧮 Simulador Dinâmico de Reinvestimento Compilado
              </h5>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] text-zinc-500 uppercase font-black block">Valor do Novo Aporte (Capital)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range"
                      min="500"
                      max="20000"
                      step="500"
                      value={newAporteAmount}
                      onChange={e => setNewAporteAmount(Number(e.target.value))}
                      className="flex-1 accent-amber-400 h-1"
                    />
                    <span className="text-xs font-bold text-amber-400 font-mono w-16 text-right">{formatBRL(newAporteAmount)}</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] text-zinc-500 uppercase font-black block">Taxa de Juros do Contrato (%)</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range"
                      min="10"
                      max="50"
                      value={newAporteRate}
                      onChange={e => setNewAporteRate(Number(e.target.value))}
                      className="flex-1 accent-amber-400 h-1"
                    />
                    <span className="text-xs font-bold text-amber-400 font-mono w-10 text-right">{newAporteRate}%</span>
                  </div>
                </div>
              </div>

              {/* Simulation outputs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-900">
                  <span className="text-[8px] text-zinc-550 uppercase font-bold block">Retorno Bruto</span>
                  <span className="text-xs font-bold font-mono text-zinc-200 block mt-1">
                    {formatBRL(newAporteAmount * (1 + newAporteRate/100))}
                  </span>
                </div>
                <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-900">
                  <span className="text-[8px] text-zinc-550 uppercase font-bold block">Lucro de Juros</span>
                  <span className="text-xs font-bold font-mono text-emerald-400 block mt-1">
                    {formatBRL(newAporteAmount * (newAporteRate/100))}
                  </span>
                </div>
                <div className="bg-zinc-950 p-2.5 rounded-xl border border-zinc-900 col-span-2">
                  <span className="text-[8px] text-zinc-550 uppercase font-bold block">Reinvestimento de 1 Ano (Compounding)</span>
                  <span className="text-xs font-bold font-mono text-yellow-500 block mt-1">
                    {/* Compound calculation over 12 cycles assuming 1 cycle per month */}
                    {formatBRL(newAporteAmount * Math.pow(1 + newAporteRate/100, 12))}
                  </span>
                </div>
              </div>

              <div className="text-[10px] text-zinc-500 leading-normal font-mono bg-zinc-950/40 p-3 rounded-xl border border-zinc-900/50">
                💡 Ao manter o investimento de <strong>{formatBRL(newAporteAmount)}</strong> sempre girando na carteira, no final de 12 ciclos reinvestindo os juros gerados, o seu montante crescerá exponencialmente para impressionantes <strong>{formatBRL(newAporteAmount * Math.pow(1 + newAporteRate/100, 12))}</strong>!
              </div>
            </div>
          </div>
        )}
      </div>

      {/* SECTION 2: ADIMPLÊNCIA / INADIMPLÊNCIA METRICS SEGMENT (Pagantes vs Inadimplentes) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* PAYERS VS DELINQUENTS RATIOS (5 cols) */}
        <div className="lg:col-span-5 bg-zinc-950/40 border border-zinc-850 rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-zinc-900">
            <Gauge className="w-4 h-4 text-amber-400" />
            <h4 className="font-extrabold text-xs sm:text-sm uppercase tracking-wider">Métricas de Clientes & Comportamento</h4>
          </div>

          {/* Ratios visual progress row */}
          <div className="space-y-4">
            
            {/* Paying clients metrics group */}
            <div className="bg-zinc-900/30 border border-zinc-850 p-3 rounded-xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                <div>
                  <span className="text-xs font-bold text-zinc-200 block">Clientes Pagantes (Em Dia)</span>
                  <span className="text-[10px] text-zinc-500 font-mono">Contratos ativos sem pendência</span>
                </div>
              </div>
              <span className="text-sm font-black font-mono text-zinc-100">{payingCount} <span className="text-[10px] text-zinc-500 font-normal">cli.</span></span>
            </div>

            {/* Delinquent clients metrics group (Inadimplente) */}
            <div className="bg-zinc-900/30 border border-zinc-850 p-3 rounded-xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
                <div>
                  <span className="text-xs font-bold text-zinc-200 block">Clientes Inadimplentes (Com Atraso)</span>
                  <span className="text-[10px] text-zinc-500 font-mono">Atraso superior a 1 diária</span>
                </div>
              </div>
              <span className="text-sm font-black font-mono text-amber-400">{delinquentCount} <span className="text-[10px] text-zinc-500 font-normal">cli.</span></span>
            </div>

            {/* Delinquent clients list under the card */}
            {delinquentCount > 0 && (
              <div className="bg-zinc-950/40 border border-amber-500/10 rounded-xl p-3 space-y-2 max-h-[220px] overflow-y-auto pr-1 scrollbar-thin">
                <span className="text-[9px] font-bold text-amber-400 uppercase tracking-widest font-mono block">
                  ⚠️ Clientes em Atraso para Cobrar:
                </span>
                <div className="divide-y divide-zinc-900/50 space-y-2">
                  {delinquentClients.map(client => {
                    const overdueValue = client.daysBehind * (client.activeLoan?.dailyRate || 0);
                    return (
                      <div key={client.activeLoan ? `delinquent-loan-${client.activeLoan.id}` : `delinquent-client-${client.client.id}`} className="pt-2 flex items-center justify-between gap-2 text-xs">
                        <div className="min-w-0 flex-1">
                          <span className="font-bold text-zinc-200 block truncate">{client.client.name}</span>
                          <span className="text-[9px] text-zinc-500 font-mono block">
                            {client.daysBehind}x em atraso • Total: <strong className="text-red-400">{new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(overdueValue)}</strong>
                          </span>
                        </div>
                        <button
                          onClick={() => {
                            if (!client.activeLoan) return;
                            const formattedPhone = `55${client.client.phone.replace(/\D/g, "")}`;
                            const dateFormatted = client.referenceDate 
                              ? client.referenceDate.split("-").reverse().join("/") 
                              : client.activeLoan.startDate.split("-").reverse().join("/");
                            const message = `Olá *${client.client.name}*, tudo bem? Passando para lembrar da sua parcela diária de *R$ ${client.activeLoan.dailyRate.toFixed(2)}*. Progresso: *${client.paidCount} de ${client.totalDays} pagas*. Última atualização: *${dateFormatted}*. Você possui *${client.daysBehind} parcelas em atraso*. Chave Pix (E-mail): lagoscelular5@gmail.com`;
                            window.open(`https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`, "_blank");
                          }}
                          className="px-2 py-1 bg-amber-500/10 hover:bg-amber-400 text-amber-400 hover:text-zinc-950 font-black text-[10px] rounded-lg border border-amber-500/20 transition-all flex items-center gap-1 shrink-0 cursor-pointer"
                        >
                          Cobrar
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Overdue capital metrics group */}
            <div className="bg-zinc-900/30 border border-zinc-850 p-3 rounded-xl flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                <div>
                  <span className="text-xs font-bold text-zinc-200 block">Capital Ativo em Atraso</span>
                  <span className="text-[10px] text-zinc-500 font-mono">Soma de depósitos vencidos acumulados</span>
                </div>
              </div>
              <span className="text-sm font-black font-mono text-red-400">{formatBRL(totalOverdueAmount)}</span>
            </div>

            {/* General Default Risk Rate indicator */}
            <div className="space-y-1.5 pt-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-zinc-500 font-bold uppercase">Índice de Inadimplência Geral</span>
                <span className="text-amber-400 font-black">{defaultRateByClient.toFixed(1)}%</span>
              </div>
              <div className="w-full bg-zinc-900 rounded-full h-2 overflow-hidden">
                <div 
                  className="bg-amber-400 h-full rounded-full transition-all duration-300"
                  style={{ width: `${defaultRateByClient}%` }}
                />
              </div>
              <div className="flex justify-between text-[9px] text-zinc-500 font-mono pt-0.5">
                <span>0% Risco de Perda</span>
                <span>Alerta Crítico &gt; 35%</span>
              </div>
            </div>

            {/* BLINDAGEM DE LUCRO INTERACTIVE MATHEMATICS CARD */}
            <div className="border-t border-zinc-900 pt-4 mt-2 space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h5 className="font-extrabold text-[11px] uppercase tracking-wider text-zinc-300">Estrutura de Blindagem de Margem ({customInterestRate}%)</h5>
              </div>
              
              <div className="space-y-2 text-xs">
                {/* Break-even indicator */}
                <div className="flex justify-between items-center py-1.5 px-3 bg-zinc-900/30 rounded-xl border border-zinc-900">
                  <span className="text-zinc-400 text-[10px] uppercase font-mono">Ponto de Equilíbrio (Break-Even)</span>
                  <span className="font-bold text-zinc-100 font-mono">{breakEvenInterestRate.toFixed(1)}%</span>
                </div>
                
                {/* Net Safe Return rate */}
                <div className="flex justify-between items-center py-1.5 px-3 bg-zinc-900/40 rounded-xl border border-emerald-500/10">
                  <span className="text-emerald-400 text-[10px] uppercase font-bold font-mono">Margem Real Total Estimada</span>
                  <span className={`font-black font-mono ${netInvestmentYieldProfit >= 0 ? "text-emerald-400" : "text-amber-500"}`}>
                    {netInvestmentYieldProfit >= 0 ? "+" : ""}{netInvestmentYieldProfit.toFixed(1)}%
                  </span>
                </div>
                
                {/* Max Delinquency Tolerance limit */}
                <div className="flex justify-between items-center py-1.5 px-3 bg-zinc-900/30 rounded-xl border border-zinc-900">
                  <span className="text-zinc-400 text-[10px] uppercase font-mono">Limite para Suportar Perdas</span>
                  <span className="font-bold text-red-400 font-mono">{maxDefaultTolerance.toFixed(1)}% <span className="text-[9px] text-zinc-500">atraso</span></span>
                </div>
              </div>

              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
                <p className="text-[10px] text-emerald-400 leading-normal text-justify font-mono">
                  ✨ <strong>Cálculos Prontos:</strong> Com a taxa padrão de <strong>{customInterestRate}%</strong>, sua carteira de repasse está blindada. Mesmo que a inadimplência chegue a <strong>{maxDefaultTolerance.toFixed(1)}%</strong>, seu capital inicial permanece intocado. Cada ciclo gerará lucro real que, se reinvestido, garante a meta de <strong>crescer a carteira 20% ao mês</strong> de forma robusta e recorrente!
                </p>
              </div>
            </div>

          </div>
        </div>

        {/* 20% MoM GROWTH EVOLUTION & SIMULATOR PANEL (7 cols) */}
        <div className="lg:col-span-7 bg-zinc-950/40 border border-zinc-850 rounded-2xl p-5 space-y-5">
          <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4.5 h-4.5 text-amber-400" />
              <h4 className="font-extrabold text-xs sm:text-sm uppercase tracking-wider">Plano de Expansão e Crescimento MoM</h4>
            </div>
            <span className="bg-amber-400/10 border border-amber-400/20 text-amber-400 text-[10px] font-bold px-2 py-0.5 rounded-lg font-mono">
              Meta: +{simulationMoMGrace}% / mês
            </span>
          </div>

          <p className="text-xs text-zinc-400 leading-normal">
            Este simulador inteligente avalia a sua carteira ativa, calcula o impacto do índice de 
            <strong className="text-zinc-200"> inadimplência real ({defaultRateByClient.toFixed(0)}%)</strong> e planeja quanto capital precisa ser injetado para subir o faturamento recorrente.
          </p>

          {/* Interactive controls */}
          <div className="grid grid-cols-2 gap-4 bg-zinc-900/30 p-4 rounded-xl border border-zinc-850 select-none">
            
            <div className="space-y-1.5">
              <label className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider block">Meta de Crescimento (%)</label>
              <div className="flex items-center gap-2">
                <input 
                  type="range"
                  min="5"
                  max="50"
                  value={simulationMoMGrace}
                  onChange={e => setSimulationMoMGrace(Number(e.target.value))}
                  className="flex-1 accent-amber-400 h-1"
                />
                <span className="text-xs font-bold text-amber-400 font-mono w-8 text-right">{simulationMoMGrace}%</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-[10px] text-zinc-400 uppercase font-bold tracking-wider block">Juros Médio Praticado (%)</label>
              <div className="flex items-center gap-2">
                <input 
                  type="range"
                  min="10"
                  max="100"
                  value={customInterestRate}
                  onChange={e => setCustomInterestRate(Number(e.target.value))}
                  className="flex-1 accent-amber-400 h-1"
                />
                <span className="text-xs font-bold text-amber-400 font-mono w-8 text-right">{customInterestRate}%</span>
              </div>
            </div>

          </div>

          {/* SIMULATION MATHEMATICS RESULTS CONTAINER */}
          <div className="space-y-3.5 pt-1">
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              
              <div className="bg-zinc-900/60 p-3 rounded-xl border border-zinc-850/60 space-y-1">
                <span className="text-[9px] text-zinc-550 uppercase font-black font-mono block">Faturamento Atual</span>
                <span className="text-sm font-bold text-zinc-250 font-mono block">
                  {formatBRL(currentBillingForGrowth)}
                </span>
                <span className="text-[9px] text-zinc-500 block">Projeção mensal ativa</span>
              </div>

              <div className="bg-zinc-900/60 p-3 rounded-xl border border-zinc-850/60 space-y-1">
                <span className="text-[9px] text-zinc-550 uppercase font-black font-mono block">Nova Meta de Faturamento</span>
                <span className="text-sm font-bold text-emerald-400 font-mono block">
                  {formatBRL(targetMonthlyBilling)}
                </span>
                <span className="text-[9px] text-zinc-500 block">+{simulationMoMGrace}% de crescimento</span>
              </div>

              <div className="bg-zinc-900/60 p-3 rounded-xl border border-zinc-850/60 space-y-1">
                <span className="text-[9px] text-zinc-550 uppercase font-black font-mono block">Aumento Líquido Requerido</span>
                <span className="text-sm font-bold text-amber-400 font-mono block">
                  {formatBRL(targetBillingChangeNeeded)}
                </span>
                <span className="text-[9px] text-zinc-500 block">Incremento real de caixa</span>
              </div>

            </div>

            {/* HIGHLIGHTED INSTRUCTION: QUANTO PRECISA EMPRESTAR HOJE */}
            <div className="bg-gradient-to-r from-amber-950/20 to-zinc-900/40 border border-amber-500/25 p-4 rounded-xl space-y-3">
              <div className="flex justify-between items-start gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] text-amber-400 font-extrabold uppercase tracking-widest font-mono block">
                    Capital a Emprestar Necessário
                  </span>
                  <strong className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight block">
                    {formatBRL(requiredCapitalToLend)}
                  </strong>
                </div>
                <div className="p-2.5 bg-amber-400 text-zinc-950 rounded-xl shadow-lg shadow-amber-400/10 shrink-0">
                  <ArrowUpRight className="w-5 h-5 stroke-[2.5]" />
                </div>
              </div>

              <div className="text-[11px] text-zinc-400 leading-relaxed font-mono pt-1 text-justify">
                💡 <span className="text-amber-400 font-bold">Diagnóstico Operacional:</span> Para crescer seu faturamento em <span className="text-zinc-200 font-bold">{simulationMoMGrace}%</span>, você precisa liberar <span className="text-zinc-200 font-bold">{formatBRL(requiredCapitalToLend)}</span> em novos empréstimos com taxa de <span className="text-zinc-200 font-bold">{customInterestRate}%</span>. 
                Este cálculo foi compensado em <span className="text-amber-400 font-bold">{(defaultRatioFactor * 100).toFixed(0)}%</span> para suportar o atraso de maus pagadores detectados na sua carteira. 
                Isso equivale a aproximadamente <span className="text-zinc-250 font-bold">{contractsCountNeeded} novos contratos</span> de {formatBRL(averageLoanSize)} cada um.
              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
